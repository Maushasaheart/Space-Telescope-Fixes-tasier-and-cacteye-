CactEyeParallaxFix 0.3.1
Experimental Tarsier rendering compatibility build

INSTALL
1. Close KSP completely.
2. Delete the old GameData/CactEyeParallaxFix folder.
3. Copy this ZIP's GameData folder into your KSP installation.
4. Keep the old global Parallax Scaled disabling CFG outside GameData.
5. Start KSP and test Duna in Tarsier, then a Jool moon and CactEye.

Only GameData is needed to run. Source and Tests are optional.
Do not install the reference DLLs from your uploaded ZIP into GameData.
Do not keep multiple copies of CactEyeParallaxFix.dll.

CHANGES
CactEye keeps its existing texture residency behavior and two second grace period.
Tarsier preview and full resolution screenshot targets use a fifteen second grace period.
A direct zero argument void Unload method is guarded if the installed Parallax runtime exposes it. That extra guard applies only to Tarsier target holds. The existing visibility guard remains active for both telescopes.
During Tarsier's scaled camera render only, supported material properties are temporarily changed:
_MaxTessellation = 1
_DisableDisplacement = 1
The original values are restored by the camera post render callback, with outer render finalizer cleanup if the draw throws. Scene changes and plugin shutdown also restore them. Other camera post render callbacks do not clear the settings prematurely.
Color maps, normal maps and shader selection are retained. Terrain and scatters are not changed. Normal game renders retain their original settings after the temporary render finishes.

TRADEOFF AND LIMITS
Tarsier temporarily renders without Parallax height displacement and with minimum tessellation. Its planet silhouette may look less detailed.
This is an experimental compatibility workaround, not a confirmed root cause fix. Duna working differently from Jool's moons does not by itself prove tessellation is responsible. Atmosphere, configuration and precision differences may still matter.
Limiting tessellation does not bypass the hull shader entirely. Native graphics problems may persist.
This does not fix TSTSpaceTelescope.getZoomString exceptions, catalogs or target selection.
If a material does not expose the controls, the plugin logs the supported count rather than swapping its shader.
The residency hold temporarily uses more memory after switching targets.

VERIFICATION
Compiled using the exact KSP, Unity and Harmony reference DLLs uploaded for this task.
Assembly inspection: CactEyeParallaxFix 0.3.1.0; CLR v4.0.30319; Harmony 2.2.1.0 reference.
41 simulated checks passed. See Tests/RESULTS.txt.
Tests use simulated Unity and Parallax objects. They do not execute native shaders or Harmony runtime patch installation.
No KSP visual testing was possible in this environment.

SOURCE BASIS
Recovered 0.3.0 source from the existing package.
Inspected upstream TSTCameraModule.cs, ParallaxScaled.shader and ParallaxScaledUtils.cginc on 2026-09-30. The shader exposes both controls, and its displacement macro checks _DisableDisplacement. Tarsier manually renders scaled cameras and uses a 3e15 far clip plane.
These are upstream master files, not a byte verified copy of your installed shader.
https://github.com/JPLRepo/TarsierSpaceTechnology
https://github.com/Gameslinx/Parallax-Continued

DIAGNOSTICS
Search KSP.log for [CactEyeParallaxFix v3.1].
Startup should list patches for TSTCameraModule.draw and drawFS.
Tarsier safe rendering: Duna; supported properties=2/2 confirms both controls were applied.
Textures ready records the color map size.
A direct texture unload guard line means the optional Unload hook was available.
If Duna still glitches, send a screenshot and the new KSP.log.

UNINSTALL
Close KSP and remove GameData/CactEyeParallaxFix.
No save files are modified.

BUILD
Source/build.cmd rebuilds on Windows with .NET Framework's C# compiler.
Run it with the KSP installation path and installed 0Harmony.dll path.
KSP and mod reference assemblies are deliberately not redistributed.
