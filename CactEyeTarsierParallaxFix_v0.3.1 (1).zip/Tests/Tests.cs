using System;
using System.Reflection;
using UnityEngine;
using Parallax;
using Parallax.Scaled_System;
class Tests {
 static int count;
 static readonly Type t=typeof(CactEyeParallaxFix);
 static object Call(string n,params object[] a){return t.GetMethod(n,BindingFlags.NonPublic|BindingFlags.Static).Invoke(null,a);}
 static void Set(string n,object v){t.GetField(n,BindingFlags.NonPublic|BindingFlags.Static).SetValue(null,v);}
 static void Check(bool v,string n){if(!v)throw new Exception("FAIL "+n);count++;Console.WriteLine("PASS "+n);}
 static ParallaxScaledBody Add(string name,float x,float z){var b=new CelestialBody{name=name,Radius=1};b.scaledBody.transform.position=new Vector3(x,0,z);FlightGlobals.Bodies[name]=b;var p=new ParallaxScaledBody{planetName=name};ConfigLoader.parallaxScaledBodies[name]=p;return p;}
 static void Main(){
  var plugin=new CactEyeParallaxFix();
  var cact=typeof(CactEye2.CactEyeCamera);var tst=typeof(TarsierSpaceTech.TSTCameraModule);
  var both=(System.Collections.Generic.List<MethodInfo>)Call("FindRenderMethods",cact,tst);
  Check(both.Count==3,"both mods hook all three render paths");
  var onlyTst=(System.Collections.Generic.List<MethodInfo>)Call("FindRenderMethods",null,tst);
  Check(onlyTst.Count==2 && onlyTst[0].Name=="draw" && onlyTst[1].Name=="drawFS","Tarsier alone hooks preview and screenshot");
  Check(((System.Collections.Generic.List<MethodInfo>)Call("FindRenderMethods",cact,null)).Count==1,"CactEye alone remains supported");
  Check(((System.Collections.Generic.List<MethodInfo>)Call("FindRenderMethods",null,null)).Count==0,"no telescope mods returns no hooks");
  var sceneMethod=t.GetMethod("SceneChanging",BindingFlags.Instance|BindingFlags.NonPublic);
  Check(sceneMethod!=null && !sceneMethod.IsStatic,"KSP scene handler is an instance method");
  var sceneCallback=(Action<GameScenes>)Delegate.CreateDelegate(typeof(Action<GameScenes>),plugin,sceneMethod);
  GameEvents.onGameSceneLoadRequested.Add(sceneCallback);
  Check(ReferenceEquals(sceneCallback.Target,plugin),"KSP event registration has a nonnull delegate target");

  Check(ScopeVisibility.NeedsTextures(0,0,1000,1,1,1,400,.1,1e9),"zoomed planet needs textures");
  Check(!ScopeVisibility.NeedsTextures(0,0,1000,1,60,1,400,.1,1e9),"same planet subpixel at normal zoom");
  Check(!ScopeVisibility.NeedsTextures(100,0,1000,1,1,1,400,.1,1e9),"planet outside telescope view excluded");
  Check(!ScopeVisibility.NeedsTextures(0,0,-1000,1,1,1,400,.1,1e9),"planet behind telescope excluded");
  Check(ScopeVisibility.NeedsTextures(9,0,1000,1,1,1,400,.1,1e9),"planet limb touching image retained");
  Check(!ScopeVisibility.NeedsTextures(0,0,1000,1,0,1,400,.1,1e9),"invalid zoom ignored");
  Check(!ScopeVisibility.NeedsTextures(double.NaN,0,1000,1,1,1,400,.1,1e9),"invalid coordinates ignored");
  Set("bodyTable",typeof(ConfigLoader).GetField("parallaxScaledBodies"));Set("componentBody",typeof(ScaledOnDemandComponent).GetField("scaledBody"));Set("pendingUnload",typeof(ScaledOnDemandComponent).GetField("pendingUnload"));
  Set("planetName",typeof(ParallaxScaledBody).GetField("planetName"));Set("scaledMaterial",typeof(ParallaxScaledBody).GetField("scaledMaterial"));Set("loaded",typeof(ParallaxScaledBody).GetProperty("Loaded"));Set("loading",typeof(ParallaxScaledBody).GetProperty("IsLoading"));Set("load",typeof(ParallaxScaledBody).GetMethod("Load"));Set("ready",true);
  var target=Add("Target",0,1000);var away=Add("Away",100,1000);var mat=target.scaledMaterial;
  var cam=new Camera{name="CactEye 2 Camera ScaledSpace"};
  Call("BeforeCamera",cam);Check(target.loads==0,"automatic camera render outside CactEye request ignored");
  object[] begin={0};Call("BeginRender",begin);var normal=new Camera{name="Camera ScaledSpace"};Call("BeforeCamera",normal);Check(target.loads==0,"normal camera untouched during request");
  Call("BeforeCamera",cam);Check(target.loads==1 && target.Loaded,"target loaded through Parallax API");Check(away.loads==0,"unrelated body not loaded");Check(ReferenceEquals(mat,target.scaledMaterial),"original Parallax material retained");Check(mat.GetFloat("_MaxTessellation")==64 && mat.GetFloat("_DisableDisplacement")==0,"CactEye shader properties untouched");
  var demand=new ScaledOnDemandComponent{scaledBody=target};Check(!(bool)Call("KeepVisibleTextures",demand) && !demand.pendingUnload,"main camera cannot unload telescope target");
  Call("BeforeCamera",cam);Check(target.loads==1,"already loaded target not loaded repeatedly");
  var error=new Exception("camera failure");Check(ReferenceEquals(error,Call("EndRender",error,begin[0])),"camera exception preserved by cleanup");Time.realtimeSinceStartup=3;Check((bool)Call("KeepVisibleTextures",demand),"normal texture management resumes after grace period");
  var asyncBody=Add("Async",0,1000);asyncBody.IsLoading=true;begin[0]=0;Call("BeginRender",begin);Call("BeforeCamera",cam);Check(asyncBody.loads==0,"existing async load not duplicated");
  var broken=Add("Broken",0,1000);broken.fail=true;Call("BeforeCamera",cam);int attempts=broken.loads;Call("BeforeCamera",cam);Check(attempts==1 && broken.loads==1,"failed load uses retry cooldown");
  t.GetMethod("SceneChanging",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(plugin,new object[]{GameScenes.SPACECENTER});Check((bool)Call("KeepVisibleTextures",demand),"scene change clears holds");
  Call("BeforeCamera",cam);Check(target.loads==1,"scene change clears render scope");
  
  var tstTarget=Add("TarsierTarget",0,1000);var tstCam=new Camera{name="TST_Camera ScaledSpace"};
  Call("BeforeCamera",tstCam);Check(tstTarget.loads==0,"Tarsier camera outside scoped draw ignored");
  begin[0]=0;Call("BeginRender",begin);Call("BeforeCamera",tstCam);
  Check(tstTarget.loads==1 && tstTarget.Loaded,"Tarsier preview loads target");
  Check(tstTarget.scaledMaterial.GetFloat("_MaxTessellation")==1 && tstTarget.scaledMaterial.GetFloat("_DisableDisplacement")==1,"Tarsier uses safe properties during render");
  Call("AfterCamera",new Camera{name="Other"});
  Check(tstTarget.scaledMaterial.GetFloat("_MaxTessellation")==1,"unrelated camera callback does not restore prematurely");
  object[] nestedSafe={0};Call("BeginRender",nestedSafe);Call("EndRender",null,nestedSafe[0]);
  Check(tstTarget.scaledMaterial.GetFloat("_MaxTessellation")==1,"nested scope cleanup preserves outer material state");
  Call("AfterCamera",tstCam);
  Check(tstTarget.scaledMaterial.GetFloat("_MaxTessellation")==64 && tstTarget.scaledMaterial.GetFloat("_DisableDisplacement")==0,"post render restores original shader values");
  Check(!(bool)Call("KeepResident",tstTarget),"direct unload blocked during hold");
  Time.realtimeSinceStartup=17;
  Check(!(bool)Call("KeepResident",tstTarget),"Tarsier hold survives fourteen seconds");
  Time.realtimeSinceStartup=19;
  Check((bool)Call("KeepResident",tstTarget),"Tarsier hold expires after fifteen seconds");
  Call("BeforeCamera",tstCam);
  Call("EndRender",new Exception("render failure"),begin[0]);
  Check(tstTarget.scaledMaterial.GetFloat("_MaxTessellation")==64,"exception finalizer restores materials");
  var fsBody=Add("FullResolution",0,100000);var screenshot=new Camera{name="TST_Camera ScaledSpace",targetTexture=new RenderTexture{height=2160}};
  begin[0]=0;Call("BeginRender",begin);Call("BeforeCamera",tstCam);
  Check(fsBody.loads==0,"subpixel planet excluded at preview size");
  Call("BeforeCamera",screenshot);Check(fsBody.loads==1,"full resolution screenshot uses its own pixel height");
  var stray=Add("Stray",0,1000);Call("BeforeCamera",new Camera{name="TST_Camera 00"});
  Check(stray.loads==0,"Tarsier local camera excluded");
  object[] nested={0};Call("BeginRender",nested);Call("EndRender",null,nested[0]);Call("BeforeCamera",tstCam);
  Check(stray.loads==1,"nested render cleanup preserves outer telescope scope");
  Call("EndRender",null,begin[0]);
  Console.WriteLine(count+" checks passed. Simulated objects; no Unity visual validation.");
 }
}
