using System;
using System.Collections.Generic;
namespace UnityEngine {
 public class Object {public string name;public static void DontDestroyOnLoad(Object o){}}
 public class GameObject:Object {public Transform transform=new Transform();}
 public class Component:Object {public GameObject gameObject=new GameObject();}
 public class MonoBehaviour:Component{}
 public class Texture:Object {public int width=4096,height=2048;}
 public class Texture2D:Texture{}
 public class RenderTexture:Texture{}
 public class Shader:Object {}
 public class Material:Object {public Shader shader=new Shader{name="ParallaxScaled"};public Dictionary<string,float> values=new Dictionary<string,float>{{"_MaxTessellation",64f},{"_DisableDisplacement",0f}};public float GetFloat(string n){return values[n];}public void SetFloat(string n,float v){values[n]=v;}public int GetInt(string n){return (int)values[n];}public void SetInt(string n,int v){values[n]=v;}public Texture color=new Texture();public bool HasProperty(string n){return n=="_ColorMap" || values.ContainsKey(n);}public Texture GetTexture(string n){return color;}}
 public struct Vector3 {public float x,y,z;public Vector3(float a,float b,float c){x=a;y=b;z=c;}public static Vector3 operator -(Vector3 a,Vector3 b){return new Vector3(a.x-b.x,a.y-b.y,a.z-b.z);}public static float Dot(Vector3 a,Vector3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}}
 public class Transform {public Vector3 position;public Vector3 right=new Vector3(1,0,0),up=new Vector3(0,1,0),forward=new Vector3(0,0,1);}
 public class Camera:Object {public static Action<Camera> onPreCull;public static Action<Camera> onPostRender;public int actualRenderingPath=1;public int pixelHeight=400;public RenderTexture targetTexture=new RenderTexture{height=400};public float fieldOfView=1,aspect=1,nearClipPlane=0.1f,farClipPlane=1e15f;public Transform transform=new Transform();}
 public static class Time {public static float realtimeSinceStartup;}
 public static class Debug {public static List<string> messages=new List<string>();public static void Log(object o){messages.Add(o.ToString());}public static void LogWarning(object o){Log(o);}public static void LogError(object o){Log(o);}}
}
public class KSPAddon:Attribute {public enum Startup{Instantly}public KSPAddon(Startup s,bool b){}}
public enum GameScenes{FLIGHT,SPACECENTER}
public class EventData<T>{public void Add(Action<T>a){var originatorType=a.Target.GetType().Name;}public void Remove(Action<T>a){}}
public static class GameEvents{public static EventData<GameScenes> onGameSceneLoadRequested=new EventData<GameScenes>();}
public static class HighLogic{public static bool LoadedSceneIsFlight=true;}
public class CelestialBody{public string name;public double Radius;public UnityEngine.GameObject scaledBody=new UnityEngine.GameObject();}
public static class FlightGlobals{public static Dictionary<string,CelestialBody>Bodies=new Dictionary<string,CelestialBody>();public static CelestialBody GetBodyByName(string name){CelestialBody b;return Bodies.TryGetValue(name,out b)?b:null;}}
public static class ScaledSpace{public const float InverseScaleFactor=1f;}
namespace Parallax {
 public static class ConfigLoader{public static Dictionary<string,ParallaxScaledBody>parallaxScaledBodies=new Dictionary<string,ParallaxScaledBody>();}
 public class ParallaxScaledBody{public string planetName;public UnityEngine.Material scaledMaterial=new UnityEngine.Material();public bool Loaded{get;set;}public bool IsLoading{get;set;}public bool fail;public int loads;public void Load(){loads++;if(fail)throw new Exception("test load failure");Loaded=true;}}
 namespace Scaled_System {public class ScaledOnDemandComponent {public ParallaxScaledBody scaledBody;public bool pendingUnload=true;}}
}
namespace CactEye2 {class CactEyeCamera {public UnityEngine.Texture2D UpdateTexture(object processor,UnityEngine.RenderTexture rt,UnityEngine.Texture2D output){return output;}public UnityEngine.Texture2D UpdateTexture(object processor){return null;}}}
namespace TarsierSpaceTech {public class TSTCameraModule {internal UnityEngine.Texture2D draw(){return null;}internal UnityEngine.Texture2D drawFS(){return null;}}}
