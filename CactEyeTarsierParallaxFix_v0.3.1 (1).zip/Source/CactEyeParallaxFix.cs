using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

[assembly: AssemblyVersion("0.3.1.0")]
[assembly: AssemblyFileVersion("0.3.1.0")]
[assembly: AssemblyDescription("CactEye and Tarsier aware Parallax Scaled texture residency.")]

[KSPAddon(KSPAddon.Startup.Instantly, true)]
public sealed class CactEyeParallaxFix : MonoBehaviour
{
    const string Owner = "CactEyeParallaxFix.textureResidency.v2";
    const float GraceSeconds = 2.0f;
    const float TarsierGraceSeconds = 15.0f;
    sealed class Entry
    {
        internal object scaled;
        internal CelestialBody body;
        internal string name;
        internal float holdUntil = -1;
        internal float retryAfter;
        internal float tarsierHoldUntil = -1;
        internal bool reportedTexture;
    }
    static readonly Dictionary<object, Entry> entries = new Dictionary<object, Entry>();
    static Harmony harmony;
    static FieldInfo bodyTable, componentBody, pendingUnload, planetName, scaledMaterial;
    static PropertyInfo loaded, loading;
    static MethodInfo load;
    static int renderDepth;
    static bool ready, failed;
    static readonly HashSet<string> announcedCameras = new HashSet<string>();
    sealed class MaterialState
    {
        internal Material material;
        internal string property;
        internal float value;
        internal bool integer;
    }
    static readonly List<MaterialState> safeState = new List<MaterialState>();
    static readonly HashSet<string> safeReports = new HashSet<string>();
    static Camera safeCamera;
    static IDictionary cachedTable;
    static int cachedCount = -1;
    bool cameraSubscribed;
    bool sceneSubscribed;

    void Awake()
    {
        DontDestroyOnLoad(gameObject);
        try
        {
            Type cameraType = AccessTools.TypeByName("CactEye2.CactEyeCamera");
            Type tarsierType = AccessTools.TypeByName("TarsierSpaceTech.TSTCameraModule");
            Type configType = AccessTools.TypeByName("Parallax.ConfigLoader");
            Type demandType = AccessTools.TypeByName("Parallax.Scaled_System.ScaledOnDemandComponent");
            if (configType == null || demandType == null)
                throw new NotSupportedException("Parallax Scaled runtime type missing.");
            List<MethodInfo> renders = FindRenderMethods(cameraType, tarsierType);
            MethodInfo visibility = AccessTools.Method(demandType, "UpdateVisibility");
            bodyTable = AccessTools.Field(configType, "parallaxScaledBodies");
            componentBody = AccessTools.Field(demandType, "scaledBody");
            pendingUnload = AccessTools.Field(demandType, "pendingUnload");
            if (renders.Count == 0 || visibility == null || bodyTable == null || componentBody == null || pendingUnload == null)
                throw new NotSupportedException("Required camera or texture loader hook missing.");
            Type scaledType = componentBody.FieldType;
            loaded = AccessTools.Property(scaledType, "Loaded");
            loading = AccessTools.Property(scaledType, "IsLoading");
            load = AccessTools.Method(scaledType, "Load", Type.EmptyTypes);
            planetName = AccessTools.Field(scaledType, "planetName");
            scaledMaterial = AccessTools.Field(scaledType, "scaledMaterial");
            if (loaded == null || loading == null || load == null || planetName == null || scaledMaterial == null)
                throw new NotSupportedException("Required Parallax Scaled body API missing.");

            harmony = new Harmony(Owner);
            foreach (MethodInfo render in renders)
            {
                harmony.Patch(render, prefix: new HarmonyMethod(typeof(CactEyeParallaxFix), "BeginRender"),
                    finalizer: new HarmonyMethod(typeof(CactEyeParallaxFix), "EndRender"));
                Debug.Log("[CactEyeParallaxFix v3.1] Patched " + render.DeclaringType.FullName + "." + render.Name);
            }
            harmony.Patch(visibility, prefix: new HarmonyMethod(typeof(CactEyeParallaxFix), "KeepVisibleTextures"));
            MethodInfo unload = AccessTools.Method(scaledType, "Unload", Type.EmptyTypes);
            if (unload != null && unload.ReturnType == typeof(void) && !unload.IsStatic)
            {
                harmony.Patch(unload, prefix: new HarmonyMethod(typeof(CactEyeParallaxFix), "KeepResident"));
                Debug.Log("[CactEyeParallaxFix v3.1] Patched direct texture unload guard: " + unload);
            }
            Camera.onPostRender += AfterCamera;
            Camera.onPreCull += BeforeCamera;
            cameraSubscribed = true;
            GameEvents.onGameSceneLoadRequested.Add(SceneChanging);
            sceneSubscribed = true;
            ready = true;
            Debug.Log("[CactEyeParallaxFix v3.1] Ready; Scaled rendering stays enabled. CactEye="
                + (cameraType == null ? "absent" : cameraType.Assembly.GetName().Version.ToString())
                + "; Tarsier=" + (tarsierType == null ? "absent" : tarsierType.Assembly.GetName().Version.ToString())
                + "; Parallax=" + configType.Assembly.GetName().Version);
        }
        catch (Exception e)
        {
            ready = false;
            Unsubscribe();
            if (harmony != null) harmony.UnpatchAll(Owner);
            Debug.LogError("[CactEyeParallaxFix v3.1] Inactive: " + e);
        }
    }

    static List<MethodInfo> FindRenderMethods(Type cactEye, Type tarsier)
    {
        var result = new List<MethodInfo>();
        const BindingFlags flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        if (cactEye != null)
            foreach (MethodInfo method in cactEye.GetMethods(flags))
            {
                ParameterInfo[] p = method.GetParameters();
                if (method.Name == "UpdateTexture" && p.Length == 3 && p[1].ParameterType == typeof(RenderTexture)
                    && p[2].ParameterType == typeof(Texture2D)) { result.Add(method); break; }
            }
        if (tarsier != null)
            foreach (string name in new[] { "draw", "drawFS" })
            {
                MethodInfo method = tarsier.GetMethod(name, flags, null, Type.EmptyTypes, null);
                if (method != null && method.ReturnType == typeof(Texture2D)) result.Add(method);
            }
        return result;
    }

    static void BeginRender(out int __state)
    {
        __state = renderDepth;
        renderDepth++;
    }
    // Finalizer also runs when CactEye throws; preserve its original exception.
    static Exception EndRender(Exception __exception, int __state)
    {
        if (__state == 0) RestoreMaterials();
        renderDepth = __state;
        return __exception;
    }
    static bool KeepResident(object __instance)
    {
        Entry entry;
        return !ready || failed || !HighLogic.LoadedSceneIsFlight ||
            !entries.TryGetValue(__instance, out entry) || Time.realtimeSinceStartup >= entry.tarsierHoldUntil;
    }
    static void RestoreMaterials()
    {
        try
        {
            foreach (MaterialState state in safeState)
                if (state.material != null)
                {
                    if (state.integer) state.material.SetInt(state.property, (int)state.value);
                    else state.material.SetFloat(state.property, state.value);
                }
        }
        finally { safeState.Clear(); safeCamera = null; }
    }
    static void AfterCamera(Camera camera)
    {
        if (camera == safeCamera) RestoreMaterials();
    }
    static void MakeSafe(Entry entry, Camera camera)
    {
        Material material = scaledMaterial.GetValue(entry.scaled) as Material;
        if (material == null) return;
        safeCamera = camera;
        int changed = 0;
        foreach (string property in new[] { "_MaxTessellation", "_DisableDisplacement" })
        {
            if (!material.HasProperty(property)) continue;
            bool saved = false;
            foreach (MaterialState old in safeState)
                if (old.material == material && old.property == property) { saved = true; break; }
            if (!saved)
                safeState.Add(new MaterialState { material = material, property = property, value = property == "_DisableDisplacement" ? material.GetInt(property) : material.GetFloat(property), integer = property == "_DisableDisplacement" });
            if (property == "_DisableDisplacement") material.SetInt(property, 1);
            else material.SetFloat(property, 1f);
            changed++;
        }
        if (safeReports.Add(entry.name))
            Debug.Log("[CactEyeParallaxFix v3.1] Tarsier safe rendering: " + entry.name +
                "; supported properties=" + changed + "/2; shader=" + (material.shader == null ? "missing" : material.shader.name));
    }
    static bool KeepVisibleTextures(object __instance)
    {
        if (!ready || failed || !HighLogic.LoadedSceneIsFlight) return true;
        object scaled = componentBody.GetValue(__instance);
        Entry entry;
        if (scaled == null || !entries.TryGetValue(scaled, out entry) ||
            Time.realtimeSinceStartup >= entry.holdUntil) return true;
        // The normal loader uses only the main camera. Leave its shadow Update
        // and any async load coroutine running, but cancel its pending unload.
        pendingUnload.SetValue(__instance, false);
        return false;
    }
    static void RefreshEntries()
    {
        IDictionary table = bodyTable.GetValue(null) as IDictionary;
        if (table == null) return;
        if (ReferenceEquals(table, cachedTable) && table.Count == cachedCount) return;
        RestoreMaterials();
        safeReports.Clear();
        entries.Clear();
        cachedTable = table;
        cachedCount = table.Count;
        foreach (DictionaryEntry pair in table)
        {
            object scaled = pair.Value;
            if (scaled == null) continue;
            string name = planetName.GetValue(scaled) as string;
            CelestialBody body = FlightGlobals.GetBodyByName(name);
            if (body == null || body.scaledBody == null) continue;
            entries[scaled] = new Entry { scaled = scaled, body = body, name = name };
        }
        if (table.Count == 0)
            Debug.LogWarning("[CactEyeParallaxFix v3.1] No Parallax Scaled bodies. Remove the old disabling CFG and restart KSP.");
    }
    static void BeforeCamera(Camera camera)
    {
        if (!ready || failed || renderDepth == 0 || !HighLogic.LoadedSceneIsFlight || camera == null) return;
        bool isCactEye = camera.name.IndexOf("CactEye", StringComparison.OrdinalIgnoreCase) >= 0 &&
            camera.name.IndexOf("ScaledSpace", StringComparison.OrdinalIgnoreCase) >= 0;
        bool isTarsier = string.Equals(camera.name, "TST_Camera ScaledSpace", StringComparison.OrdinalIgnoreCase);
        if (!isCactEye && !isTarsier) return;
        try
        {
            if (announcedCameras.Add(camera.name))
            {
                Debug.Log("[CactEyeParallaxFix v3.1] Telescope render detected: " + camera.name
                    + "; renderingPath=" + camera.actualRenderingPath);
            }
            RefreshEntries();
            if (isTarsier) RestoreMaterials();
            int height = camera.targetTexture != null ? camera.targetTexture.height : camera.pixelHeight;
            Vector3 origin = camera.transform.position;
            Vector3 right = camera.transform.right;
            Vector3 up = camera.transform.up;
            Vector3 forward = camera.transform.forward;
            foreach (Entry entry in entries.Values)
            {
                if (entry.body == null || entry.body.scaledBody == null) continue;
                Vector3 offset = entry.body.scaledBody.transform.position - origin;
                double radius = entry.body.Radius * ScaledSpace.InverseScaleFactor;
                if (!ScopeVisibility.NeedsTextures(Vector3.Dot(offset, right), Vector3.Dot(offset, up),
                    Vector3.Dot(offset, forward), radius, camera.fieldOfView, camera.aspect, height,
                    camera.nearClipPlane, camera.farClipPlane)) continue;

                float now = Time.realtimeSinceStartup;
                if (now < entry.retryAfter) continue;
                bool newlyHeld = now >= entry.holdUntil;
                entry.holdUntil = now + (isTarsier ? TarsierGraceSeconds : GraceSeconds);
                if (newlyHeld)
                    Debug.Log("[CactEyeParallaxFix v3.1] Holding telescope textures: " + entry.name);
                try
                {
                    bool isLoaded = (bool)loaded.GetValue(entry.scaled, null);
                    bool isLoading = (bool)loading.GetValue(entry.scaled, null);
                    if (!isLoaded && !isLoading)
                    {
                        // Use Parallax's own loader. Never interrupt an async load
                        // or manually assign textures, materials, shaders or cameras.
                        load.Invoke(entry.scaled, null);
                        entry.reportedTexture = false;
                    }
                    entry.holdUntil = Time.realtimeSinceStartup + (isTarsier ? TarsierGraceSeconds : GraceSeconds);
                    if (isTarsier) entry.tarsierHoldUntil = entry.holdUntil;
                    if (isTarsier && (bool)loaded.GetValue(entry.scaled, null)) MakeSafe(entry, camera);
                    if ((bool)loaded.GetValue(entry.scaled, null) && !entry.reportedTexture)
                    {
                        Material material = scaledMaterial.GetValue(entry.scaled) as Material;
                        Texture color = material != null && material.HasProperty("_ColorMap")
                            ? material.GetTexture("_ColorMap") : null;
                        string details = color == null ? "no _ColorMap available" :
                            "_ColorMap=" + color.width + "x" + color.height;
                        Debug.Log("[CactEyeParallaxFix v3.1] Textures ready: " + entry.name + "; " + details);
                        entry.reportedTexture = true;
                    }
                }
                catch (Exception e)
                {
                    // Do not retain a failed body or continuously retry per frame.
                    entry.holdUntil = -1;
                    entry.retryAfter = Time.realtimeSinceStartup + 5;
                    Debug.LogError("[CactEyeParallaxFix v3.1] Could not load " + entry.name + ": " + e);
                }
            }
        }
        catch (Exception e)
        {
            RestoreMaterials();
            failed = true;
            entries.Clear();
            Debug.LogError("[CactEyeParallaxFix v3.1] Paused after error; normal texture control restored: " + e);
        }
    }
    // KSP EventData inspects delegate.Target.GetType() during registration.
    // This handler must be an instance method: a static delegate has no target.
    void SceneChanging(GameScenes scene)
    {
        RestoreMaterials();
        safeReports.Clear();
        entries.Clear();
        cachedTable = null;
        cachedCount = -1;
        renderDepth = 0;
        announcedCameras.Clear();
    }
    void OnDestroy()
    {
        ready = false;
        RestoreMaterials();
        Unsubscribe();
        entries.Clear();
        if (harmony != null) harmony.UnpatchAll(Owner);
    }
    void Unsubscribe()
    {
        if (cameraSubscribed)
        {
            Camera.onPreCull -= BeforeCamera;
            Camera.onPostRender -= AfterCamera;
            cameraSubscribed = false;
        }
        if (sceneSubscribed)
        {
            GameEvents.onGameSceneLoadRequested.Remove(SceneChanging);
            sceneSubscribed = false;
        }
    }
}
