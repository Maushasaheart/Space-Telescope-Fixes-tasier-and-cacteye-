@echo off
setlocal
if "%~2"=="" (
 echo Usage: build.cmd "C:\KSP" "C:\KSP\GameData\000_Harmony\0Harmony.dll"
 exit /b 1
)
set "KSPREF=%~1\KSP_x64_Data\Managed"
set "CSCOMPILER=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSCOMPILER%" set "CSCOMPILER=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSCOMPILER%" (
 echo Install the .NET Framework developer tools to obtain csc.exe.
 exit /b 1
)
"%CSCOMPILER%" /nologo /target:library /nostdlib /reference:"%KSPREF%\mscorlib.dll" /reference:"%KSPREF%\System.dll" /reference:"%KSPREF%\System.Core.dll" /reference:"%KSPREF%\Assembly-CSharp.dll" /reference:"%KSPREF%\UnityEngine.dll" /reference:"%KSPREF%\UnityEngine.CoreModule.dll" /reference:"%~2" /out:"%~dp0..\GameData\CactEyeParallaxFix\Plugins\CactEyeParallaxFix.dll" "%~dp0CactEyeParallaxFix.cs" "%~dp0ScopeVisibility.cs"
exit /b %errorlevel%
